<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>index-2</title>
<link href="style css/style.css" rel="stylesheet" type="text/css" />
</head>

<body><div id="page">
  <div id="haut">
    <h1><img src="img/LOGO en-tete.gif" width="96" height="51" />  Ma Biblio en ligne</h1>
  </div>
  <div id="nav">
    <ul>
      <li></li>
      <li><a href="Parcourir la bibliotheque.php">Parcourir la bibliothèque</a></li>
      <li><a href="Prets en cours.php">Prêts en cours</a></li>
      <li><a href="Information du compte.php">Information du compte</a></li>
      <li><a href="logout.php">Se déconnecter</a></li>
    </ul>
  </div>
  <div id="contenu">
    <h1>Bienvenue sur Biblio, le site de</h1>
    <h1>la bibliothèque de &quot;Pontault-Combault&quot;.</h1>
    <h2><img src="img/logo book.png" width="150" height="97" class="img-left" /></h2>
    <h2>&nbsp;</h2>
    <h2>Une bibliothèque en ligne accessible à tous ! </h2>
    <p>&nbsp;</p>
  </div>
  <div id="pied">
    <p>Tous droits réservés <strong>©</strong> Ma Biblio, Ghislaine Chtayna</p>
  </div>
</div>
</body>
</html>